import pygame
import sys
import random

# --- 1. CONFIGURATION CONSTANTS (Joint Agreement) ---
PROJECT_NAME = "Autonomous Air Traffic Control for Drones"

# Grid and Screen dimensions
GRID_SIZE = 15          # The simulation is 15x15 cells
CELL_SIZE = 40          # Each cell is 40x40 pixels
WIDTH = GRID_SIZE * CELL_SIZE
HEIGHT = GRID_SIZE * CELL_SIZE

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (200, 50, 50)     
BLUE = (50, 50, 200)    
GREEN = (50, 200, 50)   
OBSTACLE_COLOR = (100, 100, 100) # Gray for Buildings

# Static Data: Obstacles/Buildings (Crucial for Layer 1)
# Defined by their (grid_x, grid_y) coordinates
STATIC_OBSTACLES = [
    (3, 4), (3, 5), (3, 6), (3, 7), # Vertical Block 1
    (7, 7), (7, 8), (7, 9),         # Vertical Block 2
    (11, 2), (12, 2), (13, 2),      # Horizontal Block 1
    (1, 10), (2, 10), (3, 10), (4, 10), (5, 10) # Horizontal Block 2
]

# --- 2. DRONE CLASS (Foundation for Layer 2: Tactical Agent) ---
class Drone:
    def __init__(self, drone_id, start_pos_grid, color):
        self.id = drone_id
        self.color = color
        
        # Grid Coordinates: Used for Layer 1/2 logic
        self.grid_pos = list(start_pos_grid)
        
        # Pixel Coordinates: Used by Pygame for drawing
        self.x, self.y = self._grid_to_pixel(self.grid_pos)

        # Movement/Physics State (Layer 2 AI will update these)
        self.velocity = [0.0, 0.0]  # [vx, vy] speed in pixels per frame
        self.max_speed = 1.0        # Max speed limit (reduced for visibility)

    def _grid_to_pixel(self, grid_coords):
        """Converts grid coordinates to screen pixel coordinates (center of cell)."""
        gx, gy = grid_coords
        center_x = gx * CELL_SIZE + CELL_SIZE // 2
        center_y = gy * CELL_SIZE + CELL_SIZE // 2
        return center_x, center_y
        
    def _pixel_to_grid(self):
        """Updates grid_pos based on current pixel coordinates."""
        gx = max(0, min(GRID_SIZE - 1, int(self.x // CELL_SIZE)))
        gy = max(0, min(GRID_SIZE - 1, int(self.y // CELL_SIZE)))
        self.grid_pos = [gx, gy]

    def update(self):
        """Updates the drone's position based on its velocity vector."""
        # 1. Apply the velocity (set by Layer 2's AI policy later)
        self.x += self.velocity[0]
        self.y += self.velocity[1]
        
        # 2. Keep drone within screen boundaries
        self.x = max(CELL_SIZE // 2, min(self.x, WIDTH - CELL_SIZE // 2))
        self.y = max(CELL_SIZE // 2, min(self.y, HEIGHT - CELL_SIZE // 2))

        # 3. Update the grid position
        self._pixel_to_grid()

    def draw(self, screen):
        """Draws the drone as a colored circle with its ID."""
        radius = CELL_SIZE // 4
        
        # Draw the main drone body
        pygame.draw.circle(screen, self.color, (int(self.x), int(self.y)), radius)
        
        # Draw the Drone ID for debugging
        font = pygame.font.Font(None, 18)
        text = font.render(str(self.id), True, BLACK)
        screen.blit(text, (self.x - text.get_width() // 2, self.y - text.get_height() // 2))

# --- 3. SIMULATION CORE FUNCTIONS ---

def draw_grid(screen):
    """Draws the visual grid lines."""
    for x in range(0, WIDTH, CELL_SIZE):
        pygame.draw.line(screen, BLACK, (x, 0), (x, HEIGHT))
    for y in range(0, HEIGHT, CELL_SIZE):
        pygame.draw.line(screen, BLACK, (0, y), (WIDTH, y))

def draw_obstacles(screen):
    """Draws the static obstacles (buildings)."""
    for gx, gy in STATIC_OBSTACLES:
        # Convert grid coordinates (gx, gy) to pixel position (top-left corner)
        x = gx * CELL_SIZE
        y = gy * CELL_SIZE
        
        # Draw a filled gray rectangle for the obstacle
        rect = pygame.Rect(x, y, CELL_SIZE, CELL_SIZE)
        pygame.draw.rect(screen, OBSTACLE_COLOR, rect)

def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption(PROJECT_NAME)
    clock = pygame.time.Clock()
    
    # Initialize the fleet (Dynamic Data)
    drones = [
        Drone(drone_id=1, start_pos_grid=(1, 1), color=RED),
        Drone(drone_id=2, start_pos_grid=(GRID_SIZE - 2, GRID_SIZE - 2), color=BLUE),
        Drone(drone_id=3, start_pos_grid=(14, 0), color=GREEN) # Placed near an edge
    ]

    # TEMP: Set placeholder movement that interacts with the obstacles
    drones[0].velocity = [0.8, 0.0]  # Moves right, towards the first block
    drones[1].velocity = [-0.4, -0.4] # Moves diagonally, potentially crossing obstacles
    drones[2].velocity = [-0.8, 0.8] # Moves down-left

    running = True
    while running:
        # Event Handling
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        # --- UPDATE PHASE (Your future AI logic goes here) ---
        # 1. Layer 1 (Strategic Planner) logic will run here to calculate corridors.
        # 2. Layer 2 (Tactical Agent) logic will run here to set drone velocities 
        #    based on the corridors and real-time avoidance needs.
        
        # Update all drones' positions
        for drone in drones:
            drone.update()
        
        # --- DRAW PHASE ---
        screen.fill(WHITE) # Clear screen
        
        # Draw obstacles (must be before the grid lines)
        draw_obstacles(screen) 
        
        # Draw grid lines
        draw_grid(screen)
        
        # Draw all drones (must be last to appear on top)
        for drone in drones:
            drone.draw(screen)
        
        pygame.display.flip() # Update the display
        clock.tick(60)       # Cap the frame rate

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()